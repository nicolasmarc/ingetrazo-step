"""Read the IngeTrazo scene into plain :class:`model.Part` objects.

Duck-typed on purpose (no Qt import): positions only need ``x() y() z()``,
so the tests drive it with small fakes. One part per top-level group or
component (its nested pieces are folded in, world coordinates), plus the
loose geometry as one more part, split later into its separate shells.
"""
from collections import Counter
from .model import Face, Part
from .texts import texts



def _xyz(p):
    return (float(p.x()), float(p.y()), float(p.z()))


_TEXTURE_RGB = {}


def texture_rgb(path):
    """Mean colour (r, g, b in 0..1) of a texture image, or None when it
    cannot be read. Read once per file, from a 32 x 32 reduction: a CAD
    program shows one colour per body, and the mean of the picture (beech
    light brown, concrete grey) is closer to what the model shows than no
    colour at all. Qt reads the image (present inside IngeTrazo)."""
    if not path:
        return None
    if path in _TEXTURE_RGB:
        return _TEXTURE_RGB[path]
    rgb = None
    try:
        from PySide6.QtCore import Qt
        from PySide6.QtGui import QImage
        img = QImage(str(path))
        if not img.isNull():
            img = img.convertToFormat(QImage.Format_RGB888).scaled(
                32, 32, Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
            w, h, bpl = img.width(), img.height(), img.bytesPerLine()
            raw = bytes(img.constBits())[:bpl * h]
            tot, n = [0, 0, 0], 0
            for y in range(h):
                row = raw[y * bpl:y * bpl + 3 * w]
                for k in range(3):
                    tot[k] += sum(row[k::3])
                n += w
            if n:
                rgb = tuple(round(t / n / 255.0, 4) for t in tot)
    except Exception:                        # no Qt, unreadable file
        rgb = None
    _TEXTURE_RGB[path] = rgb
    return rgb


def _shown_rgb(attrs):
    """A face's colour: its paint colour when it has one (a textured
    material often carries one, chosen to stand for it), else the mean
    colour of its texture."""
    attrs = attrs or {}
    c = attrs.get("color")
    if c is not None and len(c) >= 3:
        return tuple(round(float(x), 4) for x in c[:3])
    tex = attrs.get("texture")
    if isinstance(tex, dict) and tex.get("path"):
        return texture_rgb(tex["path"])
    return None


def _color(faces, paint=None):
    """The part's colour: the one most of its faces show. A face wearing
    the default material takes the group's paint (``paint``), as in the
    viewport."""
    cols = []
    for f in faces:
        attrs = getattr(f, "attrs", None) or {}
        if paint and not (attrs.get("color") or attrs.get("texture")):
            attrs = paint
        rgb = _shown_rgb(attrs)
        if rgb is not None:
            cols.append(rgb)
    return Counter(cols).most_common(1)[0][0] if cols else None


def strip_triangles(face):
    """Triangles for a warped STRIP face (the chamfer or edge band of a
    curved stringer or handrail): its border is two long chains, each
    shared with one side face, joined by two short ends. The strip is cut
    rung by rung between the chains, always along the shorter diagonal —
    short, well-shaped triangles that follow the surface, instead of the
    long slivers a planar ear-clip makes across it. ``None`` when the face
    is not such a strip."""
    loop = list(getattr(face, "loop", []) or [])
    n = len(loop)
    if n < 6:
        return None

    def other(a, b):
        """The neighbour across edge a-b, as a key: stacked duplicates of
        one face (same corners) count as one neighbour."""
        for e in a.edges if hasattr(a, "edges") else ():
            if e.has(b) if hasattr(e, "has") else (e.v0 is b or e.v1 is b):
                keys = {frozenset(id(v) for v in g.loop)
                        for g in e.faces if g is not face}
                return next(iter(keys)) if len(keys) == 1 else None
        return None

    nb = [other(loop[k], loop[(k + 1) % n]) for k in range(n)]
    if any(x is None for x in nb):
        return None
    # runs of consecutive edges against the same neighbour face
    start = next((k for k in range(n) if nb[k] != nb[k - 1]), None)
    if start is None:
        return None
    runs, cur = [], [start]
    for k in range(1, n + 1):
        i = (start + k) % n
        if k < n and nb[i] == nb[cur[-1]]:
            cur.append(i)
        else:
            runs.append(cur)
            cur = [i]
    if len(runs) != 4:
        return None
    lens = [len(r) for r in runs]
    if not (min(lens[0], lens[2]) > max(lens[1], lens[3])
            or min(lens[1], lens[3]) > max(lens[0], lens[2])):
        return None
    if lens[1] > lens[0]:
        runs = runs[1:] + runs[:1]
    ra, rb = runs[0], runs[2]
    A = [loop[i] for i in ra] + [loop[(ra[-1] + 1) % n]]
    B = [loop[i] for i in rb] + [loop[(rb[-1] + 1) % n]]
    B = B[::-1]                         # run alongside A
    P = lambda v: _xyz(v.position)
    a, b = [P(v) for v in A], [P(v) for v in B]

    def d(p, q):
        return sum((x - y) ** 2 for x, y in zip(p, q))
    tris, i, j = [], 0, 0
    while i < len(a) - 1 or j < len(b) - 1:
        if j == len(b) - 1 or (i < len(a) - 1
                               and d(a[i + 1], b[j]) <= d(a[i], b[j + 1])):
            tris.append([a[i], a[i + 1], b[j]])
            i += 1
        else:
            tris.append([a[i], b[j + 1], b[j]])
            j += 1
    return tris


def faces_part(name, faces, edges=(), paint=None):
    """A Part from mesh faces (``vertices`` / ``holes`` positions) and the
    soft edges among ``edges``; ``paint``: the group's own material."""
    from .check import PLANAR_TOL, _is_planar
    faces = list(faces)
    out = []
    for f in faces:
        outer = [_xyz(p) for p in f.vertices]
        holes = [[_xyz(p) for p in h] for h in (f.holes or [])]
        if len(outer) > 3 and hasattr(f, "triangulate") \
                and not _is_planar([outer] + holes, PLANAR_TOL):
            # a warped face (helical stringer, twisted strip): IngeTrazo's
            # own triangulation, the one it draws, rather than ours
            sid = id(f)
            tris = strip_triangles(f) if not holes else None
            if tris is None:
                tris = [[_xyz(p) for p in tri] for tri in f.triangulate()]
            for tri in tris:
                out.append(Face(tri, src=sid))
            continue
        out.append(Face(outer, holes))
    soft = [(_xyz(e.a), _xyz(e.b)) for e in edges if getattr(e, "soft", False)]
    return Part(name, out, _color(faces, paint), soft or None)


def _cage_in_world(group, mesh, pts):
    """The SubD cage points where the group's surface is now: the
    Subdivision extension remembers a few surface points when it builds
    the group and carries the cage along with them; the same fit is used
    here (its own module when installed, else the centroid's move)."""
    from .subdnurbs import cage_payload
    _key, data = cage_payload(getattr(group, "ext", None))
    ref = (data or {}).get("ref")
    if not ref:
        return pts
    positions = [_xyz(v.position) for v in getattr(mesh, "vertices", [])]
    try:
        from subdiv.follow import apply_point, fit
        aff = fit(ref, positions)
        return pts if aff is None else [apply_point(aff, p) for p in pts]
    except Exception:
        pass
    if not positions:
        return pts
    n = len(positions)
    c = [sum(p[k] for p in positions) / n for k in range(3)]
    d = [c[k] - float(ref["c"][k]) for k in range(3)]
    return [tuple(p[k] + d[k] for k in range(3)) for p in pts]


def nurbs_part(name, group, mesh, paint=None, tol=1e-4, mode="panels"):
    """A Part holding the group's SubD surface as B-spline faces, or None
    when the group is not a SubD body."""
    from .subdnurbs import cage_payload, cage_to_nurbs_tol, from_ext
    key, payload = cage_payload(getattr(group, "ext", None))
    data = from_ext(getattr(group, "ext", None))
    if data is None:
        return None
    pts, fs, cr = data
    if not pts or not fs:
        return None
    if key == "subdiv_source":
        # a finished body: its cage still describes it only while the mesh
        # is the one Finish made (moved, turned or scaled is fine)
        n = payload.get("nverts"), payload.get("nfaces")
        if n != (len(getattr(mesh, "vertices", [])), len(getattr(mesh, "faces", []))):
            return "edited"
    pts = _cage_in_world(group, mesh, pts)
    sh = cage_to_nurbs_tol(pts, fs, cr, tol=tol, mode=mode)
    return Part(name, [], _color(mesh.faces, paint), None, nurbs=sh)


def collect_parts(scene, selection_only=False, world_mesh=None, subd_nurbs=False,
                  nurbs_tol=1e-4, nurbs_mode="panels"):
    """-> list of Part. ``selection_only``: the selected groups, and the
    selected loose faces. ``subd_nurbs``: SubD bodies (the Subdivision
    extension's groups) as B-spline faces rebuilt from their cage, within
    ``nurbs_tol`` metres of the true surface, instead of their facets;
    ``nurbs_mode``: ``"panels"`` (one face per cage quad) or ``"patches"``
    (small Bezier patches)."""
    if world_mesh is None:                       # pragma: no cover - in app
        from core.group import world_mesh
    visible = getattr(scene, "entity_visible", lambda _e: True)
    sel = set(getattr(scene, "selection", ()) or ()) if selection_only else None
    parts, names = [], Counter()

    def unique(name):
        names[name] += 1
        return name if names[name] == 1 else f"{name} ({names[name]})"

    for g in getattr(scene, "groups", []):
        if not visible(g) or getattr(g, "billboard", False):
            continue
        if sel is not None and g not in sel:
            continue
        mesh = world_mesh(g)
        if not mesh.faces:
            continue
        paint = getattr(g, "material", None)
        paint = paint if isinstance(paint, dict) else None
        name = unique(str(getattr(g, "name", "Groupe")))
        if subd_nurbs:
            part = nurbs_part(name, g, mesh, paint, nurbs_tol, nurbs_mode)
            if part == "edited":
                part = faces_part(name, mesh.faces, mesh.edges, paint)
                part.subd_edited = True
                parts.append(part)
                continue
            if part is not None:
                parts.append(part)
                continue
        parts.append(faces_part(name, mesh.faces, mesh.edges, paint))
    loose = getattr(scene, "loose_mesh", None)
    if loose is not None:
        fs = [f for f in loose.faces if visible(f)
              and (sel is None or f in sel)]
        if fs:
            keep = set(map(id, fs))
            es = [e for e in loose.edges
                  if any(id(f) in keep for f in getattr(e, "faces", ()))]
            parts.append(faces_part(unique(texts()["loose"]), fs, es))
    return parts


def _reason(T, text):
    table = T.get("reasons", {})
    base, _, rest = text.partition(" (")
    if text in table:
        return table[text]
    if base in table:                        # "unsupported topology (3 loops)"
        return f"{table[base]} ({rest}"
    return text


def format_report(rep, unit="mm", lang=None):
    """Plain-text summary of a :func:`writer.write_step` report, in the
    IngeTrazo language (English or French)."""
    T = texts(lang)
    u3 = {"mm": 1e-3, "cm": 1.0, "m": 1e6,          # -> cm3
          "in": 16.387064, "ft": 28316.846592}[unit]
    lines = [T["summary"].format(s=rep["solids"], o=rep["shells"], f=rep["faces"],
                                 c=rep.get("cylinders", 0))]
    for p in rep["parts"]:
        for sh in p["shells"]:
            state = T["solid"] if sh["closed"] else T["open"]
            line = f"• {sh['name']} — {state}, " + T["faces"].format(n=sh["faces"])
            if sh.get("facets", sh["faces"]) != sh["faces"]:
                line += T["instead"].format(n=sh["facets"])
            if sh["closed"]:
                line += f", {sh['volume'] * u3:.2f} cm³"
            lines.append(line)
            if sh.get("nurbs"):
                nb = sh["nurbs"]
                lines.append("    ◦ " + T["nurbs_line"].format(f=nb["faces"],
                                                              g=f"{nb['gap']:.3g} {unit}"))
            for c in sh.get("cylinders", []):
                what = (T["rod"] if c["full"] else T["round"]) if c["convex"] else \
                       (T["hole"] if c["full"] else T["fillet"])
                ang = "" if c["full"] else f", {c['span']:.0f}°"
                lines.append(f"    ◦ {what} Ø{2 * c['radius']:.2f} {unit}"
                             f" (R{c['radius']:.2f}{ang}, {c['facets']} {T['facets']})")
            for c in sh.get("rejected", []):
                lines.append(f"    ◦ {T['kept']}: R{c['radius']:.2f} {unit} — {_reason(T, c['reason'])}")
            for pb in sh["problems"]:
                lines.append(f"    ⚠ {_reason(T, pb)}")
    for n in rep["notes"]:
        for en, loc in T.get("notes", {}).items():
            n = n.replace(en, loc)
        lines.append(f"⚠ {n}")
    return "\n".join(lines)
